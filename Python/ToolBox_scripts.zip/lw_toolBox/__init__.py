import sys

if 'D:/Documents/FALL 2020/3670 scripting/3670-scripting/Python' not in sys.path:
    sys.path.append('D:/Documents/FALL 2020/3670 scripting/3670-scripting/Python')

reload(sys)

